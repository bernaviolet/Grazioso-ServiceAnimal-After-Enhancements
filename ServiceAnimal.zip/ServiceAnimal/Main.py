import RescueAnimal
from Dog import Dog
from Monkey import Monkey
from datetime import datetime


class Main:
    # Initialize dog and monkey lists
    dog_list = []
    monkey_list = []

    # Initializes lists of valid parameters for validation processes
    valid_training_status = ['Beginner', 'Intermediate', 'Complete']
    valid_countries = ['Canada', 'The Caribbean', 'Saint Pierre', 'Miquelon', 'Central America',
                       'Greenland', 'Mexico', 'United States', 'Iceland']
    valid_species = ['capuchin', 'guenon', 'macaque', 'marmoset', 'squirrel monkey', 'tamarin']

    # Displays the menu to users
    def display_menu(self):
        print('Rescue Animal System Menu')
        print('1: Intake new dog')
        print('2: Intake new monkey')
        print('3: Reserve an animal')
        print('4: Display a list of all dogs')
        print('5: Display a list of all monkeys')
        print('6: Display a list of all available animals')
        print('Q: Quit Rescue Animal')
        print('\nEnter your choice')

    # Creates a new dog object based on the user's input
    def intake_new_dog(self):
        name = input('What is the dog\'s name? ')

        # Checks to prevent duplicate dog objects
        if any(dog.name == name for dog in Main.dog_list):
            print('This dog is already in our system.')
            return
        else:
            breed = input('What is the dog\'s breed? ')
            gender = input('What is the dog\'s gender? (M/F) ')
            age = input('What is the dog\'s age? ')
            weight = input('What is the dog\'s weight in pounds? ')
            acq_date = input('What is the dog\'s acquisition date? (MM/DD/YYYY) ')
            # Checks that a valid date is entered
            valid_date = False
            while not valid_date:
                try:
                    acquisition_date = datetime.strptime(acq_date, '%m/%d/%Y')
                    break
                except ValueError:
                    print('Invalid date entered. Please enter the acquisition date in MM/DD/YYYY format.')
                    acq_date = input('What is the dog\'s acquisition date? (MM/DD/YYYY)? ')

            # Checks that a valid country is entered - will send back to main menu if invalid acquisition country
            # is entered
            valid_acq_country = False
            while not valid_acq_country:
                acquisition_country = input('What is the dog\'s acquisition country? ')
                if acquisition_country in Main.valid_countries:
                    break
                else:
                    print(f'Invalid country entered. We cannot accept dogs from {acquisition_country}.')
                    return acquisition_country

            # Checks that a valid training status is entered
            valid_training = False
            while not valid_training:
                training_status = input('What is the dog\'s training status? (Beginner, Intermediate, Completed) ')
                if training_status in Main.valid_training_status:
                    break
                else:
                    print('Invalid training status entered. Please enter Beginner, Intermediate, Completed. ')

            # Checks that a valid service country is entered
            valid_service_country = False
            while not valid_service_country:
                service_country = input('What is the dog\'s service country? ')
                if service_country in Main.valid_countries:
                    break
                else:
                    print ('Invalid country entered. Please select a different service country. ')
            reserved = False

            # Initializes new dog object from user input and adds to dog_list
            new_dog = Dog(name, breed, gender, age, weight, acquisition_date, acquisition_country, training_status,
                          reserved, service_country)
            Main.dog_list.append(new_dog)

    # Creates a new monkey object based on the user's input
    def intake_new_monkey(self):
        name = input('What is the monkey\'s name? ')

        # Checks to prevent duplicate monkey objects
        if any(monkey.name == name for monkey in Main.monkey_list):
            print('This monkey is already in our system.')
            return

        # Checks for valid species
        species = input(
            'What is the monkey\'s species? (Capuchin, Quenon, Macaque, Marmoset, Squirrel Monkey, Tamarin) ')
        if species not in Main.valid_species:
            print('Species is not eligible. ')
            return
        gender = input('What is the monkey\'s gender? (M/F) ')
        age = input('What is the monkey\'s age? ')
        weight = input('What is the monkey\'s weight in pounds and ounces? ')
        acq_date = input('What is the monkey\'s acquisition date? (MM/DD/YYYY) ')

        # Checks that a valid date is entered
        valid_date = False
        while not valid_date:
            try:
                acquisition_date = datetime.strptime(acq_date, '%m/%d/%Y')
                break
            except ValueError:
                print('Invalid date entered. Please enter the acquisition date in MM/DD/YYYY format. ')
                acq_date = input('What is the dog\'s acquisition date? (MM/DD/YYYY)? ')

        # Checks that a valid country is entered - will send back to main menu if invalid acquisition country is entered
        valid_acq_country = False
        while not valid_acq_country:
            acquisition_country = input('What is the monkey\'s acquisition country? ')
            if acquisition_country in Main.valid_countries:
                break
            else:
                print(f'Invalid country entered. We cannot accept monkeys from {acquisition_country}. ')
                return acquisition_country

        # Checks that a valid training status is entered
        valid_training = False
        while not valid_training:
            training_status = input('What is the monkey\'s training status? (Beginner, Intermediate, Completed) ')
            if training_status in Main.valid_training_status:
                break
            else:
                print('Invalid training status entered. Please enter Beginner, Intermediate, Completed. ')

        # Checks that a valid service country is entered
        valid_service_country = False
        while not valid_service_country:
            service_country = input('What is the monkey\'s service country? ')
            if service_country in Main.valid_countries:
                break
            else:
                print('Invalid country entered. Please select a different service country. ')
        tail = input('What is the monkey\'s tail length in inches? ')
        height = input('What is the monkey\'s height in inches? ')
        body = input('What is the monkey\'s body length in inches? ')
        reserved = False

        # Initializes new monkey object from user input and adds to monkey_list
        new_monkey = Monkey(name, species, gender, age, weight, acquisition_date, acquisition_country, training_status,
                            reserved, service_country, tail, height, body)
        Main.monkey_list.append(new_monkey)

    # allows the user to reserve a dog or monkey
    def reserve_animal(self):
        animal_type = input('Do you want to reserve a dog or a monkey? ').upper()
        if animal_type in ['DOG', 'DOGS']:
            desired_dog = input('Enter the name of the dog you would like to reserve: ')

            # Checks that the dog is in our system
            for dog in Main.dog_list:
                if dog.name == desired_dog:
                    # Checks that the dog isn't reserved and updates to reserved
                    if not dog.reserved:
                        dog.reserved = True
                        print(f'You have reserved {dog.name}')
                    else:
                        print(f'{desired_dog} is not available')
                    return
            print(f'{desired_dog} is not in our system')

        elif animal_type in ['MONKEY', 'MONKEYS']:
            desired_monkey = input('Enter the name of the monkey you would like to reserve: ')

            # Checks that the monkey is in our system
            for monkey in Main.monkey_list:
                if monkey.name == desired_monkey:
                    # Checks that the monkey isn't reserved and updates to reserved
                    if not monkey.reserved:
                        monkey.reserved = True
                        print(f'You have reserved {monkey.name}')
                    else:
                        print(f'{desired_monkey} is not available')
                    return
            print(f'{desired_monkey} is not in our system')

    # Displays a list of all dogs in our system
    def print_dogs(self):
        print("All Dogs:")
        for dog in Main.dog_list:
            print(dog.name)

    # Displays a list of all the monkeys in our system
    def print_monkeys(self):
        print("All Monkeys:")
        for monkey in Main.monkey_list:
            print(monkey.name)

    # Displays a list of all animals that are not reserved
    def print_animals(self):
        print("Available Dogs:")
        # Iterates through the dog list
        for dog in Main.dog_list:
            # Checks reserved status and prints available dogs
            if not dog.reserved:
                print(dog.name)

        print("Available Monkeys:")
        # Iterates through the monkey list
        for monkey in Main.monkey_list:
            # Checks reserved status and prints available monkeys
            if not monkey.reserved:
                print(monkey.name)

    # Sets the flow of the program
    def run(self):
        # Initializes while loop variable and displays the menu
        exit_program = False
        self.display_menu()

        # While loop initialization
        while not exit_program:
            user_response = input('Please enter your menu option: ').upper()

            # Calls appropriate function based on user's response
            if user_response in ['1', 'ONE']:
                self.intake_new_dog()
            elif user_response in ['2', 'TWO']:
                self.intake_new_monkey()
            elif user_response in ['3', 'THREE']:
                self.reserve_animal()
            elif user_response in ['4', 'FOUR']:
                self.print_dogs()
            elif user_response in ['5', 'FIVE']:
                self.print_monkeys()
            elif user_response in ['6', 'SIX']:
                self.print_animals()
            elif user_response in ['Q', 'QUIT']:
                print('Thank you for using the Rescue Animal System.')
                exit_program = True
            # Prompts user for a valid command when a menu option isn't entered
            else:
                print('Please enter a valid command')
            self.display_menu()


if __name__ == '__main__':
    Main().run()
